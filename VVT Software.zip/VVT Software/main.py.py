import os
import threading
import time
import cv2
import numpy as np
import tkinter as tk
import sounddevice as sd
import tkinter.filedialog
from tkinter import messagebox
from PIL import Image, ImageTk
from PIL import Image, ImageDraw
from scipy.io.wavfile import write, read
from PIL import Image, ImageDraw
import tkinter.filedialog as filedialog
import customtkinter as ctk
import tempfile
from moviepy.editor import AudioFileClip
from moviepy.editor import VideoFileClip
from pydub import AudioSegment
import noisereduce as nr

ctk.set_appearance_mode("Light")
ctk.set_default_color_theme("blue")

# === ICON CREATION ===
def create_icon(shape, size=(20, 20), color="black"):
    image = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    w, h = size
    if shape == "circle":
        draw.ellipse((4, 4, w - 4, h - 4), fill=color)
    elif shape == "square":
        draw.rectangle((4, 4, w - 4, h - 4), fill=color)
    elif shape == "triangle":
        draw.polygon([(w // 4, h // 4), (w // 4, 3 * h // 4), (3 * w // 4, h // 2)], fill=color)
    elif shape == "pause":
        draw.rectangle((5, 4, 9, h - 4), fill=color)
        draw.rectangle((11, 4, 15, h - 4), fill=color)
    elif shape == "resume":
        draw.polygon([(5, 4), (15, h // 2), (5, h - 4)], fill=color)
    elif shape == "x":
        draw.line((5, 5, w - 5, h - 5), fill=color, width=2)
        draw.line((w - 5, 5, 5, h - 5), fill=color, width=2)
    elif shape == "forward":
        draw.polygon([(5, h // 4), (5, 3 * h // 4), (12, h // 2)], fill=color)
        draw.polygon([(10, h // 4), (10, 3 * h // 4), (17, h // 2)], fill=color)
    elif shape == "backward":
        draw.polygon([(15, h // 4), (15, 3 * h // 4), (8, h // 2)], fill=color)
        draw.polygon([(10, h // 4), (10, 3 * h // 4), (3, h // 2)], fill=color)
    return ctk.CTkImage(light_image=image, dark_image=image)


# === VOICE RECORDER FRAME ===
class VoiceRecorderAppFrame(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.recording = False
        self.paused = False
        self.playing = False
        self.play_index = 0
        self.audio_data = []
        self.samplerate = 44100
        self.start_time = 0
        self.elapsed_time = 0
        self.pause_start = 0
        self.total_pause_duration = 0
        self.audio_length = 0
        self.play_audio_data = None
        self.playback_speed = 1.0


        self.icon_start_record = create_icon("circle", color="red")
        self.icon_stop_record = create_icon("square", color="black")
        self.icon_pause = create_icon("pause", color="red")
        self.icon_resume = create_icon("resume", color="black")
        self.icon_play = create_icon("triangle", color="white")
        self.icon_stop_play = create_icon("x", color="red")
        self.icon_forward = create_icon("forward", color="white")
        self.icon_backward = create_icon("backward", color="white")

        self.setup_ui()

    def setup_ui(self):
        self.action_button = ctk.CTkButton(self, image=self.icon_start_record, text="", command=self.toggle_recording, width=60)
        self.action_button.place(relx=0.4, y=30, anchor="n")

        self.pause_button = ctk.CTkButton(self, image=self.icon_pause, text="", command=self.toggle_pause, width=60)
        self.pause_button.place(relx=0.6, y=30, anchor="n")
        self.pause_button.configure(state="disabled")

        self.label_record = ctk.CTkLabel(self, text="Start Recording", font=("Arial", 12))
        self.label_record.place(relx=0.4, y=80, anchor="n")

        self.label_pause = ctk.CTkLabel(self, text="Pause", font=("Arial", 12))
        self.label_pause.place(relx=0.6, y=80, anchor="n")

        self.canvas = ctk.CTkCanvas(self, width=500, height=100, bg="white")
        self.canvas.place(relx=0.5, rely=0.2, anchor="n")
        self.waveform_data = np.zeros(500)

        self.setup_playback_controls()

        self.seek_var = tk.DoubleVar()
        self.seek_slider = ctk.CTkSlider(self, from_=0, to=1, variable=self.seek_var, command=self.seek_audio, width=500)
        self.seek_slider.place(relx=0.5, rely=0.53, anchor="n")
        self.seek_slider.configure(state="disabled")

        self.left_time_label = ctk.CTkLabel(self, text="00:00", font=("Arial", 12))
        self.left_time_label.place(relx=0.05, rely=0.53, anchor="w")

        self.right_time_label = ctk.CTkLabel(self, text="00:00", font=("Arial", 12))
        self.right_time_label.place(relx=0.95, rely=0.53, anchor="e")

        self.timer_label = ctk.CTkLabel(self, text="", font=("Arial", 14))
        self.timer_label.place(relx=0.5, rely=0.58, anchor="n")

        self.export_button = ctk.CTkButton(self, text="Save / Export", command=self.export_audio)
        self.export_button.place(relx=0.5, rely=0.65, anchor="n")

        self.import_button = ctk.CTkButton(self, text="Import Audio", command=self.import_audio)
        self.import_button.place(relx=0.5, rely=0.7, anchor="n")

        self.trim_start_entry = ctk.CTkEntry(self, placeholder_text="Start Time (sec)", width=120)
        self.trim_start_entry.place(relx=0.3, rely=0.74, anchor="n")

        self.trim_end_entry = ctk.CTkEntry(self, placeholder_text="End Time (sec)", width=120)
        self.trim_end_entry.place(relx=0.7, rely=0.74, anchor="n")

        self.trim_button = ctk.CTkButton(self, text="Trim", command=self.trim_audio)
        self.trim_button.place(relx=0.5, rely=0.79, anchor="n")
        
        self.speed_var = ctk.StringVar(value="1.0x")
        self.speed_menu = ctk.CTkOptionMenu(self, values=["0.5x", "1.0x", "1.5x", "2.0x"],
                                                      variable=self.speed_var, command=self.set_playback_speed)
        self.speed_menu.place(relx=0.5, rely=0.89, anchor="n")


    def setup_playback_controls(self):
        self.controls_frame = ctk.CTkFrame(self)
        self.controls_frame.place(relx=0.5, rely=0.4, anchor="n")

        self.backward_button = ctk.CTkButton(self.controls_frame, image=self.icon_backward, text="", command=self.skip_backward, width=40)
        self.backward_button.grid(row=0, column=0, padx=5)

        self.play_button = ctk.CTkButton(self.controls_frame, image=self.icon_play, text="", command=self.toggle_playback, state="disabled", width=60)
        self.play_button.grid(row=0, column=1, padx=5)

        self.forward_button = ctk.CTkButton(self.controls_frame, image=self.icon_forward, text="", command=self.skip_forward, width=40)
        self.forward_button.grid(row=0, column=2, padx=5)

        self.label_back = ctk.CTkLabel(self.controls_frame, text="<<5", font=("Arial", 12))
        self.label_back.grid(row=1, column=0)

        self.label_playback = ctk.CTkLabel(self.controls_frame, text="Play", font=("Arial", 12))
        self.label_playback.grid(row=1, column=1)

        self.label_forward = ctk.CTkLabel(self.controls_frame, text="5>>", font=("Arial", 12))
        self.label_forward.grid(row=1, column=2)
        
        self.add_noise_button = ctk.CTkButton(self, text="Add Noise", command=self.add_noise)
        self.add_noise_button.place(relx=0.3, rely=0.84, anchor="n")

        self.remove_noise_button = ctk.CTkButton(self, text="Remove Noise", command=self.remove_noise)
        self.remove_noise_button.place(relx=0.7, rely=0.84, anchor="n")


    def toggle_recording(self):
        if not self.recording:
            self.start_audio_recording()
        else:
            self.stop_audio_recording()

    def toggle_pause(self):
        self.paused = not self.paused
        if self.paused:
            self.pause_start = time.time()
            self.pause_button.configure(image=self.icon_resume)
            self.label_pause.configure(text="Resume")
        else:
            self.total_pause_duration += time.time() - self.pause_start
            self.pause_button.configure(image=self.icon_pause)
            self.label_pause.configure(text="Pause")

    def start_audio_recording(self):
        self.recording = True
        self.paused = False
        self.audio_data = []
        self.start_time = time.time()
        self.total_pause_duration = 0
        self.action_button.configure(image=self.icon_stop_record)
        self.label_record.configure(text="Stop Recording")
        self.pause_button.configure(state="normal")
        self.play_button.configure(state="disabled")
        self.seek_slider.configure(state="disabled")
        threading.Thread(target=self.record_audio, daemon=True).start()
        self.update_waveform()
        self.update_timer()

    def stop_audio_recording(self):
        self.recording = False
        self.action_button.configure(image=self.icon_start_record)
        self.label_record.configure(text="Start Recording")
        self.pause_button.configure(state="disabled")
        self.label_pause.configure(text="Pause")
        self.pause_button.configure(image=self.icon_pause)
        if self.audio_data:
            audio_np = np.concatenate(self.audio_data, axis=0)
            write('output_audio.wav', self.samplerate, audio_np)
            self.play_audio_data = audio_np.reshape(-1, 1)
            self.audio_length = len(audio_np) / self.samplerate
            self.play_button.configure(state="normal")
            self.seek_slider.configure(state="normal")
            self.seek_slider.set(0)
            self.right_time_label.configure(text=self.format_time(self.audio_length))
            self.timer_label.configure(text=f"Recording Finished - Total Duration: {self.format_time(self.audio_length)}")

    def toggle_playback(self):
        if not self.playing:
            self.play_audio()
        else:
            self.stop_audio()

    def play_audio(self):
        if self.play_audio_data is None:
            return
        self.playing = True
        self.play_button.configure(image=self.icon_stop_play)
        self.label_playback.configure(text="Stop")
        self.seek_slider.configure(state="normal")
        self.start_time = time.time() - self.play_index / self.samplerate
        threading.Thread(target=self._play_audio_thread, daemon=True).start()
        self.update_waveform()
        self.update_timer()

    def stop_audio(self):
        self.playing = False
        self.play_index = 0
        self.seek_slider.set(0)
        self.play_button.configure(image=self.icon_play)
        self.label_playback.configure(text="Play")

    def _play_audio_thread(self):
        total_frames = len(self.play_audio_data)

        def callback(outdata, frames, time_info, status):
            if not self.playing:
                raise sd.CallbackStop
            chunk = self.play_audio_data[self.play_index:self.play_index + frames]
            if len(chunk) < frames:
                chunk = np.pad(chunk, ((0, frames - len(chunk)), (0, 0)))
                self.playing = False
            outdata[:] = chunk
            self.waveform_data = chunk[:, 0]
            self.play_index += frames

        with sd.OutputStream(samplerate=self.samplerate, channels=1, callback=callback):
            while self.playing:
                sd.sleep(100)

        self.waveform_data = np.zeros(500)
        self.stop_audio()
        self.timer_label.configure(text="Playback")

    def seek_audio(self, value):
        if self.audio_length > 0:
            self.play_index = int(value * self.audio_length * self.samplerate)

    def update_waveform(self):
        if not (self.recording or self.playing):
            return
        if self.recording and self.paused:
            self.after(50, self.update_waveform)
            return

        self.canvas.delete("wave")
        h, w = 100, 500
        center = h // 2
        data = self.waveform_data
        if len(data) > w:
            data = data[:w]
        else:
            data = np.pad(data, (0, w - len(data)))
        scaled = data * (h // 2)
        for i in range(w):
            color = f"#00{hex(100 + i % 155)[2:]}ff"
            y = scaled[i]
            self.canvas.create_line(i, center - y, i, center + y, fill=color, tags="wave")
        self.after(50, self.update_waveform)

    def update_timer(self):
        if self.recording and not self.paused:
            self.elapsed_time = time.time() - self.start_time - self.total_pause_duration
            prefix = "Recording"
        elif self.playing:
            self.elapsed_time = time.time() - self.start_time
            prefix = "Playing"
        else:
            self.after(500, self.update_timer)
            return

        current_time_str = self.format_time(self.elapsed_time)
        self.left_time_label.configure(text=current_time_str)
        self.timer_label.configure(text=f"{prefix}: {current_time_str}")

        if self.audio_length > 0:
            self.right_time_label.configure(text=self.format_time(self.audio_length))
            self.seek_slider.set(self.play_index / (self.audio_length * self.samplerate))

        self.after(1000, self.update_timer)

    def format_time(self, seconds):
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins:02d}:{secs:02d}"

    def import_audio(self):
        file_path = filedialog.askopenfilename(filetypes=[("WAV files", "*.wav")])
        if file_path:
            samplerate, data = read(file_path)
            self.play_audio_data = data.reshape(-1, 1)
            self.samplerate = samplerate
            self.audio_length = len(self.play_audio_data) / self.samplerate
            self.play_index = 0
            self.seek_slider.configure(state="normal")
            self.play_button.configure(state="normal")
            self.seek_slider.set(0)
            self.right_time_label.configure(text=self.format_time(self.audio_length))
            self.timer_label.configure(text="Audio Imported.")

    def export_audio(self):
        if self.play_audio_data is not None:
            file_path = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV files", "*.wav")])
            if file_path:
                write(file_path, self.samplerate, self.play_audio_data)
                self.timer_label.configure(text="Audio exported successfully.")

    def trim_audio(self):
        if not os.path.exists("output_audio.wav"):
            self.timer_label.configure(text="No recorded file to trim.")
            return

        try:
            start_time = float(self.trim_start_entry.get())
            end_time = float(self.trim_end_entry.get())

            if start_time >= end_time:
                self.timer_label.configure(text="Start must be < End time.")
                return

            samplerate, data = read("output_audio.wav")
            start_sample = int(start_time * samplerate)
            end_sample = int(end_time * samplerate)

            if start_sample >= len(data) or end_sample > len(data):
                self.timer_label.configure(text="Trim range is out of bounds.")
                return

            self.play_audio_data = data[start_sample:end_sample].reshape(-1, 1)
            self.audio_length = len(self.play_audio_data) / self.samplerate
            self.play_index = 0
            self.seek_slider.configure(state="normal")
            self.play_button.configure(state="normal")
            self.seek_slider.set(0)
            self.right_time_label.configure(text=self.format_time(self.audio_length))
            self.timer_label.configure(text="Trimmed and ready for playback.")
        except Exception as e:
            self.timer_label.configure(text=f"Trim failed: {e}")
            
    def add_noise(self):
        if self.play_audio_data is not None:
            noise_level = 0.02
            noise = np.random.normal(0, noise_level, self.play_audio_data.shape)
            self.play_audio_data = np.clip(self.play_audio_data + noise, -1.0, 1.0)
            write("output_audio_noisy.wav", self.samplerate, self.play_audio_data.astype(np.float32))
            self.timer_label.configure(text="Noise Added")

    def remove_noise(self):
        if self.play_audio_data is not None:
            from scipy.signal import wiener
            cleaned = wiener(self.play_audio_data[:, 0])
            self.play_audio_data = cleaned.reshape(-1, 1).astype(np.float32)
            write("output_audio_denoised.wav", self.samplerate, self.play_audio_data)
            self.timer_label.configure(text="Noise Removed")
            
    def set_playback_speed(self, speed_label):
        speed = float(speed_label.replace("x", ""))
        self.playback_speed = speed
    

    def skip_forward(self):
        self.play_index += int(5 * self.samplerate)
        self.play_index = min(self.play_index, len(self.play_audio_data))

    def skip_backward(self):
        self.play_index -= int(5 * self.samplerate)
        self.play_index = max(self.play_index, 0)

    def record_audio(self):
        def callback(indata, frames, time_info, status):
            if self.recording and not self.paused:
                self.audio_data.append(indata.copy())
                self.waveform_data = indata[:, 0]

        with sd.InputStream(samplerate=self.samplerate, channels=1, callback=callback):
            while self.recording:
                sd.sleep(100)
    
# === VOICE RECORDER FRAME ===
class VideoRecorderAppFrame(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)

        # Directories
        os.makedirs("videos/recordings", exist_ok=True)
        self.video_path = "videos/recordings/output.avi"

        self.recording = False
        self.paused_recording = False
        self.playing = False
        self.paused_playback = False
        self.frame_rate = 20.0
        self.playback_speed = 1.0
        self.record_elapsed = 0

        self.capture = None
        self.video_writer = None
        self.total_duration = 0
        self.current_frame = 0

        self.trim_start = 0
        self.trim_end = 0

        self.available_cameras = self.get_all_camera_indices()
        self.camera_index = self.available_cameras[0]
        self.camera_dropdown = ctk.CTkOptionMenu(self, values=[f"Camera {i}" for i in self.available_cameras],
                                                           command=self.switch_camera)
        self.camera_dropdown.set(f"Camera {self.camera_index}")
        self.camera_dropdown.pack(pady=10)

        self.preview_label = ctk.CTkLabel(self, text="")
        self.preview_label.pack(pady=10)

        self.overlay_frame = ctk.CTkFrame(self.preview_label, fg_color="transparent")
        self.overlay_frame.place(relx=1.0, rely=0.0, anchor="ne", x=-10, y=10)

        self.rec_label = ctk.CTkLabel(self.overlay_frame, text="", text_color="red", font=("Arial", 18, "bold"))
        self.rec_label.pack(anchor="e")

        self.duration_label = ctk.CTkLabel(self.overlay_frame, text="", font=("Arial", 14))
        self.duration_label.pack(anchor="e")

        self.seek_frame = ctk.CTkFrame(self)
        self.seek_frame.pack(padx=40, pady=(10, 0))

        self.elapsed_time_label = ctk.CTkLabel(self.seek_frame, text="00:00")
        self.elapsed_time_label.grid(row=0, column=0, sticky="w")

        self.seek_var = ctk.DoubleVar()
        self.seek_slider = ctk.CTkSlider(self.seek_frame, from_=0, to=100, variable=self.seek_var, command=self.seek_video)
        self.seek_slider.grid(row=0, column=1, sticky="ew", padx=10)
        self.seek_frame.grid_columnconfigure(1, weight=1)

        self.total_time_label = ctk.CTkLabel(self.seek_frame, text="00:00")
        self.total_time_label.grid(row=0, column=2, sticky="e")

        self.controls_frame = ctk.CTkFrame(self)
        self.controls_frame.pack(pady=10)

        btn_font = ("Arial", 22)

        self.record_btn = ctk.CTkButton(self.controls_frame, text="🔴", font=btn_font, command=self.toggle_recording, width=60)
        self.record_btn.grid(row=0, column=0, padx=15)
        self.record_label = ctk.CTkLabel(self.controls_frame, text="Start Recording")
        self.record_label.grid(row=1, column=0)

        self.pause_resume_btn = ctk.CTkButton(self.controls_frame, text="⏸️", font=btn_font, command=self.toggle_pause_resume, width=60)
        self.pause_resume_btn.grid(row=0, column=1, padx=15)
        self.pause_resume_label = ctk.CTkLabel(self.controls_frame, text="Pause")
        self.pause_resume_label.grid(row=1, column=1)

        self.skip_back_btn = ctk.CTkButton(self.controls_frame, text="<<5", font=btn_font, command=self.skip_back, width=60)
        self.skip_back_btn.grid(row=0, column=2, padx=15)

        self.play_btn = ctk.CTkButton(self.controls_frame, text="▶️", font=btn_font, command=self.toggle_play_pause, width=60)
        self.play_btn.grid(row=0, column=3, padx=15)
        self.play_label = ctk.CTkLabel(self.controls_frame, text="Play")
        self.play_label.grid(row=1, column=3)

        self.skip_forward_btn = ctk.CTkButton(self.controls_frame, text="5>>", font=btn_font, command=self.skip_forward, width=60)
        self.skip_forward_btn.grid(row=0, column=4, padx=15)

        self.speed_label = ctk.CTkLabel(self, text="Speed:")
        self.speed_label.pack()
        self.speed_dropdown = ctk.CTkOptionMenu(self, values=["0.5x", "1x", "1.5x", "2x"], command=self.set_speed)
        self.speed_dropdown.set("1x")
        self.speed_dropdown.pack(pady=(0, 10))

        # Trimming Section
        self.trim_frame = ctk.CTkFrame(self)
        self.trim_frame.pack(pady=10)
        self.noise_frame = ctk.CTkFrame(self)
        self.noise_frame.pack(pady=10)
        
        self.noise_remove_btn = ctk.CTkButton(self.noise_frame, text="🧹 Remove Noise", command=self.apply_noise_removal)
        self.noise_remove_btn.grid(row=0, column=0, padx=10)
        
        self.noise_add_btn = ctk.CTkButton(self.noise_frame, text="🎵 Add Noise", command=self.apply_noise_addition)
        self.noise_add_btn.grid(row=0, column=1, padx=10)


        self.trim_start_entry = ctk.CTkEntry(self.trim_frame, placeholder_text="Trim Start (s)", width=140)
        self.trim_start_entry.grid(row=0, column=0, padx=5)

        self.trim_end_entry = ctk.CTkEntry(self.trim_frame, placeholder_text="Trim End (s)", width=140)
        self.trim_end_entry.grid(row=0, column=1, padx=5)

        self.trim_button = ctk.CTkButton(self.trim_frame, text="Trim Video", command=self.trim_video)
        self.trim_button.grid(row=0, column=2, padx=5)

        self.save_btn = ctk.CTkButton(self, text="💾 Save / Export", command=self.save_video)
        self.save_btn.pack(pady=(10, 20))
        
        self.import_btn = ctk.CTkButton(self, text="📁 Import Video", command=self.import_video)
        self.import_btn.pack(pady=(0, 10))

        self.preview_running = True
        self.preview_thread = threading.Thread(target=self.live_preview, daemon=True)
        self.preview_thread.start()

    def get_all_camera_indices(self, max_test=5):
        indices = []
        for i in range(max_test):
            cap = cv2.VideoCapture(i)
            if cap.read()[0]:
                indices.append(i)
            cap.release()
        return indices if indices else [0]
    
    def remove_background_noise(self, video_path, output_path):
        with tempfile.TemporaryDirectory() as tmpdir:
            temp_audio_path = os.path.join(tmpdir, "extracted.wav")
            temp_cleaned_path = os.path.join(tmpdir, "cleaned.wav")
    
            # Extract audio using moviepy
            clip = VideoFileClip(video_path)
            clip.audio.write_audiofile(temp_audio_path, logger=None)
    
            # Load with pydub
            audio = AudioSegment.from_wav(temp_audio_path)
            samples = np.array(audio.get_array_of_samples()).astype(np.float32)
            reduced_noise = nr.reduce_noise(y=samples, sr=audio.frame_rate)
    
            # Save cleaned audio
            cleaned = audio._spawn(reduced_noise.astype(audio.array_type).tobytes())
            cleaned.export(temp_cleaned_path, format="wav")
    
            # Combine cleaned audio with original video (silent)
            silent_clip = clip.without_audio()
            cleaned_audio = AudioFileClip(temp_cleaned_path)
            final = silent_clip.set_audio(cleaned_audio)
            final.write_videofile(output_path, codec="libx264", audio_codec="aac", bitrate="5000k", preset="slow", logger=None)
            clip.close()
            cleaned_audio.close()
            final.close()
            
    def apply_noise_removal(self):
        output_path = "videos/recordings/denoised_output.mp4"
        self.remove_background_noise(self.video_path, output_path)
        self.video_path = output_path
        messagebox.showinfo("Noise Removal", "Background noise removed successfully!")
        cap = cv2.VideoCapture(self.video_path)
        ret, frame = cap.read()
        if ret:
            self.update_preview(frame)
        cap.release()
    
    def apply_noise_addition(self):
        from pydub.generators import WhiteNoise
    
        with tempfile.TemporaryDirectory() as tmpdir:
            temp_audio_path = os.path.join(tmpdir, "original.wav")
            temp_noisy_path = os.path.join(tmpdir, "noisy.wav")
            temp_final_path = os.path.join(tmpdir, "noisy_video.mp4")
    
            # Extract and load audio
            clip = VideoFileClip(self.video_path)
            clip.audio.write_audiofile(temp_audio_path, logger=None)
            audio = AudioSegment.from_wav(temp_audio_path)
    
            # Generate white noise
            noise = WhiteNoise().to_audio_segment(duration=len(audio), volume=-25)
            noisy_audio = audio.overlay(noise)
            noisy_audio.export(temp_noisy_path, format="wav")
    
            # Combine with original video
            silent = clip.without_audio()
            noisy = AudioFileClip(temp_noisy_path)
            final = silent.set_audio(noisy)
            final.write_videofile(temp_final_path, codec="libx264", audio_codec="aac", bitrate="5000k", preset="slow", logger=None)
            clip.close()
            noisy.close()
            final.close()
    
            self.video_path = temp_final_path
            messagebox.showinfo("Noise Added", "Background noise added successfully.")
            cap = cv2.VideoCapture(self.video_path)
            ret, frame = cap.read()
            if ret:
                self.update_preview(frame)
            cap.release()

    
    def switch_camera(self, selected):
        cam_index = int(selected.split(" ")[1])
        if cam_index == self.camera_index:
            return  # Do nothing if the same camera is selected
    
        self.preview_running = False
        if self.capture:
            self.capture.release()
            self.capture = None
    
        time.sleep(0.5)  # Ensure camera is fully released
    
        self.camera_index = cam_index
        self.preview_running = True
        self.preview_thread = threading.Thread(target=self.live_preview, daemon=True)
        self.preview_thread.start()

    def toggle_recording(self):
        if not self.recording:
            self.start_recording()
        else:
            self.stop_recording()

    def toggle_pause_resume(self):
        if self.recording:
            self.paused_recording = not self.paused_recording
            if self.paused_recording:
                self.pause_resume_btn.configure(text="▶️")
                self.pause_resume_label.configure(text="Resume")
            else:
                self.pause_resume_btn.configure(text="⏸️")
                self.pause_resume_label.configure(text="Pause")

    def start_recording(self):
        self.preview_running = False  
        time.sleep(0.1)  
        self.recording = True
        self.paused_recording = False
        self.record_elapsed = 0
        self.record_btn.configure(text="⏹️")
        self.record_label.configure(text="Stop Recording")
        threading.Thread(target=self.record_video, daemon=True).start()
        threading.Thread(target=self.blink_rec_label, daemon=True).start()

    def stop_recording(self):
        self.recording = False
        self.paused_recording = False
        self.record_btn.configure(text="🔴")
        self.record_label.configure(text="Start Recording")
        self.pause_resume_btn.configure(text="⏸️")
        self.pause_resume_label.configure(text="Pause")
        self.rec_label.configure(text="")
        self.duration_label.configure(text="")
        if self.capture:
            self.capture.release()
        if self.video_writer:
            self.video_writer.release()

    def toggle_play_pause(self):
        if not self.playing:
            self.playing = True
            self.paused_playback = False
            self.play_btn.configure(text="⏸️")
            self.play_label.configure(text="Pause")
            threading.Thread(target=self.play_video, daemon=True).start()
        else:
            self.paused_playback = not self.paused_playback
            if self.paused_playback:
                self.play_btn.configure(text="▶️")
                self.play_label.configure(text="Play")
            else:
                self.play_btn.configure(text="⏸️")
                self.play_label.configure(text="Pause")

    def skip_forward(self):
        self.seek_var.set(min(self.seek_var.get() + 5, self.total_duration))

    def skip_back(self):
        self.seek_var.set(max(self.seek_var.get() - 5, 0))

    def set_speed(self, val):
        speed_mapping = {"0.5x": 0.5, "1x": 1.0, "1.5x": 1.5, "2x": 2.0}
        self.playback_speed = speed_mapping.get(val, 1.0)

    def record_video(self):
        self.capture = cv2.VideoCapture(self.camera_index)
        width = int(self.capture.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(self.capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fourcc = cv2.VideoWriter_fourcc(*'MJPG')
        self.video_writer = cv2.VideoWriter(self.video_path, fourcc, self.frame_rate, (width, height))
        start_time = time.time()

        while self.recording:
            if self.paused_recording:
                time.sleep(0.1)
                continue
            ret, frame = self.capture.read()
            if ret:
                self.video_writer.write(frame)
                self.update_preview(frame)
                self.record_elapsed = int(time.time() - start_time)

        self.elapsed_time_label.configure(text="00:00")
        self.total_time_label.configure(text="00:00")

    def play_video(self):
        cap = cv2.VideoCapture(self.video_path)
        fps = cap.get(cv2.CAP_PROP_FPS) or self.frame_rate
        self.total_duration = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) / fps)
        self.seek_slider.configure(to=self.total_duration)
        self.total_time_label.configure(text=f"{self.total_duration//60:02d}:{self.total_duration%60:02d}")

        while self.playing and cap.isOpened():
            if self.paused_playback:
                time.sleep(0.1)
                continue

            frame_num = int(self.seek_var.get() * fps)
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_num)
            ret, frame = cap.read()
            if not ret:
                break

            self.update_preview(frame)
            current_time = self.seek_var.get()
            self.elapsed_time_label.configure(text=f"{int(current_time)//60:02d}:{int(current_time)%60:02d}")
            self.seek_var.set(current_time + (1 / fps) * self.playback_speed)
            time.sleep((1 / fps) / self.playback_speed)

        self.playing = False
        cap.release()
        self.seek_var.set(0)
        self.play_btn.configure(text="▶️")
        self.play_label.configure(text="Play")

    def seek_video(self, val):
        if not self.playing:
            self.elapsed_time_label.configure(text=f"{int(float(val))//60:02d}:{int(float(val))%60:02d}")

    def save_video(self):
        file_path = tkinter.filedialog.asksaveasfilename(
            defaultextension=".avi",
            filetypes=[("AVI files", "*.avi"), ("MP4 files", "*.mp4")],
            title="Export Video As"
        )
        if file_path:
            extension = os.path.splitext(file_path)[1]
            if extension in [".avi", ".mp4"]:
                os.rename(self.video_path, file_path)
            messagebox.showinfo("Export Successful", f"Video saved as:\n{file_path}")
                
    def import_video(self):
        file_path = tkinter.filedialog.askopenfilename(
            filetypes=[("Video Files", "*.mp4 *.avi *.mov *.mkv")],
            title="Select a video to import"
        )
        if file_path:
            self.stop_preview()
            self.video_path = file_path
            self.imported_video = True
            cap = cv2.VideoCapture(file_path)
            ret, frame = cap.read()
            if ret:
                self.update_preview(frame)
            cap.release()
            messagebox.showinfo("Video Imported", f"Video imported successfully:\n{file_path}")
            
    def start_preview(self):
        self.preview_running = True
        self.preview_thread = threading.Thread(target=self.live_preview, daemon=True)
        self.preview_thread.start()
        
    def stop_preview(self):
        self.preview_running = False
        if self.capture:
            self.capture.release()
        time.sleep(0.3)
            
    def live_preview(self):
        if self.capture:
            self.capture.release()
        self.capture = cv2.VideoCapture(self.camera_index)
        while self.preview_running and not self.recording:
            ret, frame = self.capture.read()
            if ret:
                self.update_preview(frame)
            time.sleep(0.03)
        self.capture.release()

    def update_preview(self, frame):
        frame = cv2.resize(frame, (720, 405))
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame)
        img_tk = ImageTk.PhotoImage(image=img)
        self.preview_label.configure(image=img_tk)
        self.preview_label.image = img_tk

    def trim_video(self):
        from moviepy.editor import VideoFileClip
        try:
            start = float(self.trim_start_entry.get())
            end = float(self.trim_end_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Invalid trim times. Please enter numeric values.")
            return
    
        if start < 0 or end <= start:
            messagebox.showerror("Error", "Trim end must be greater than start and both non-negative.")
            return
    
        clip = VideoFileClip(self.video_path)
        if end > clip.duration:
            messagebox.showerror("Error", f"Trim end time exceeds video duration ({clip.duration:.2f} s).")
            return
    
        trimmed = clip.subclip(start, end)
        temp_path = "videos/recordings/trimmed_temp.mp4"
        trimmed.write_videofile(temp_path, codec="libx264", audio_codec="aac", bitrate="5000k", preset="slow")
        clip.close()
        trimmed.close()
    
        self.video_path = temp_path
        self.total_duration = end - start
        self.seek_var.set(0)
        messagebox.showinfo("Trim Complete", "Video trimmed successfully and ready for playback.")
    

    def blink_rec_label(self):
        while self.recording:
            if not self.paused_recording:
                self.rec_label.configure(text="● REC")
                self.duration_label.configure(
                    text=f"{self.record_elapsed // 60:02d}:{self.record_elapsed % 60:02d}")
                time.sleep(0.6)
                self.rec_label.configure(text="")
                time.sleep(0.6)
            else:
                self.rec_label.configure(text="⏸ Paused")
                self.duration_label.configure(
                    text=f"{self.record_elapsed // 60:02d}:{self.record_elapsed % 60:02d}")
                time.sleep(0.6)

# === MAIN APP ===
class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Software for Recording Voice & Video and Time Editing")
        self.geometry("1000x600")

        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        image_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "images")
        self.logo_image = ctk.CTkImage(Image.open(os.path.join(image_path, "audio_video_logo.jpg")), size=(40, 40))
        self.large_image = ctk.CTkImage(Image.open(os.path.join(image_path, "article.jpg")), size=(1500, 800))
        self.home_image = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "mic_light.jpg")),
                                       dark_image=Image.open(os.path.join(image_path, "mic_dark.jpg")), size=(20, 20))
        self.chats_image = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "video_light.jpg")),
                                        dark_image=Image.open(os.path.join(image_path, "video_dark.png")), size=(20, 20))
        self.users_image = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "users_dark.png")),
                                        dark_image=Image.open(os.path.join(image_path, "users_light.png")), size=(20, 20))
        self.homes_image = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "home_dark.png")),
                                        dark_image=Image.open(os.path.join(image_path, "home_light.png")), size=(20, 20))

        # === Navigation Frame ===
        self.navigation_frame = ctk.CTkFrame(self, corner_radius=0)
        self.navigation_frame.grid(row=0, column=0, sticky="nsew")

        # Grid row configuration for navigation frame
        self.navigation_frame.grid_rowconfigure(5, weight=1)  # Spacer
        self.navigation_frame.grid_columnconfigure(0, weight=1)

        # Top: Logo/Label
        self.navigation_label = ctk.CTkLabel(
            self.navigation_frame, text="  V.V.T Software",
            image=self.logo_image, compound="left",
            font=ctk.CTkFont(size=15, weight="bold")
        )
        self.navigation_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")

        # Top Buttons
        self.home_button = ctk.CTkButton(self.navigation_frame, corner_radius=0, height=40, border_spacing=0,
                                         text="Voice Recording", fg_color="transparent", text_color=("gray10", "gray90"),
                                         hover_color=("gray70", "gray30"), image=self.home_image, anchor="w",
                                         command=self.show_voice_frame)
        self.home_button.grid(row=1, column=0, padx=20, pady=5, sticky="ew")

        self.chats_button = ctk.CTkButton(self.navigation_frame, corner_radius=0, height=40, border_spacing=0,
                                          text="Video Recording", fg_color="transparent", text_color=("gray10", "gray90"),
                                          hover_color=("gray70", "gray30"), image=self.chats_image, anchor="w",
                                          command=self.show_video_frame)
        self.chats_button.grid(row=2, column=0, padx=20, pady=5, sticky="ew")

        self.button_home = ctk.CTkButton(self.navigation_frame, corner_radius=0, height=40, border_spacing=0,
                                         text="Home", fg_color="transparent", text_color=("gray10", "gray90"),
                                         hover_color=("gray70", "gray30"), image=self.homes_image, anchor="w",
                                         command=self.show_home)
        self.button_home.grid(row=3, column=0, padx=20, pady=5, sticky="ew")

        self.users_button = ctk.CTkButton(self.navigation_frame, corner_radius=0, height=40, border_spacing=0,
                                          text="Exit", fg_color="transparent", text_color=("gray10", "gray90"),
                                          hover_color=("gray70", "gray30"), image=self.users_image, anchor="w",
                                          command=self.destroy)
        self.users_button.grid(row=4, column=0, padx=20, pady=5, sticky="ew")

        # Row 5: Spacer - no widget here, just for stretching space
        self.navigation_frame.grid_rowconfigure(5, weight=1)

        # Bottom: Appearance Mode
        self.appearance_mode_label = ctk.CTkLabel(self.navigation_frame, text="Appearance Mode:", anchor="w")
        self.appearance_mode_label.grid(row=6, column=0, padx=20, pady=(10, 0), sticky="s")

        self.appearance_mode = ctk.CTkOptionMenu(self.navigation_frame, values=["Light", "Dark"],
                                                 command=self.change_appearance_mode_event)
        self.appearance_mode.grid(row=7, column=0, padx=20, pady=(0, 20), sticky="s")

        # === Main Frame ===
        self.main_frame = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.main_frame.grid(row=0, column=1, sticky="nsew")

        self.large_image_label = ctk.CTkLabel(self.main_frame, text="", image=self.large_image)
        self.large_image_label.pack(fill="both", expand=True)

        self.voice_recorder_frame = VoiceRecorderAppFrame(self.main_frame)
        self.video_recorder_frame = VideoRecorderAppFrame(self.main_frame)

        self.voice_recorder_frame.pack_forget()
        self.video_recorder_frame.pack_forget()

    def change_appearance_mode_event(self, new_appearance_mode):
        ctk.set_appearance_mode(new_appearance_mode)

    def show_voice_frame(self):
        self.large_image_label.pack_forget()
        self.video_recorder_frame.pack_forget()
        self.voice_recorder_frame.pack(fill="both", expand=True)

    def show_video_frame(self):
        self.large_image_label.pack_forget()
        self.voice_recorder_frame.pack_forget()
        self.video_recorder_frame.pack(fill="both", expand=True)

    def show_home(self):
        self.voice_recorder_frame.pack_forget()
        self.video_recorder_frame.pack_forget()
        self.large_image_label.pack(fill="both", expand=True)


if __name__ == "__main__":
    app = App()
    app.mainloop()
